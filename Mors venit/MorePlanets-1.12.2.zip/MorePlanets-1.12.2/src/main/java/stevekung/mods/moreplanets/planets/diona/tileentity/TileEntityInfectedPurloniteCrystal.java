package stevekung.mods.moreplanets.planets.diona.tileentity;

import stevekung.mods.moreplanets.utils.tileentity.TileEntityRenderTickable;

public class TileEntityInfectedPurloniteCrystal extends TileEntityRenderTickable {}