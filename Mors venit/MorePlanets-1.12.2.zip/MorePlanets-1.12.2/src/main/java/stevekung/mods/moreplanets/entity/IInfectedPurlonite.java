package stevekung.mods.moreplanets.entity;

public interface IInfectedPurlonite
{
    boolean isInfectedPurlonite();
    void setInfectedPurlonite(boolean infected);
}