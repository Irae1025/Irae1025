package stevekung.mods.moreplanets.entity;

public interface IImmuneBlackHole
{
    boolean isImmune();
}