[![](http://cf.way2muchnoise.eu/full_galacticraft-add-on-more-planets_downloads.svg)](https://minecraft.curseforge.com/projects/galacticraft-add-on-more-planets) [![](http://cf.way2muchnoise.eu/versions/Minecraft_galacticraft-add-on-more-planets_all.svg)](https://minecraft.curseforge.com/projects/galacticraft-add-on-more-planets) [![Discord](https://img.shields.io/discord/356400329086205953.svg?color=%237289da&label=discord&logo=discord&logoColor=%237289da)](https://discord.gg/54VqgZb)

More Planets
==============
An add-on exploration with custom planets for Galacticraft!